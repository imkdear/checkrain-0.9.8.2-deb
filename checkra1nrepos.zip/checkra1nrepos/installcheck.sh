sudo apt install libicu-dev
sudo apt --fix-broken install libxml2-dev
sudo dpkg -i libusbmuxd*.deb
sudo dpkg -i libplist*.deb
sudo dpkg -i libirec*.deb
sudo apt install libusbmuxd6 libplist3 libirecovery3
sudo dpkg -i checkra1n_0.9.8.2_amd64.deb


