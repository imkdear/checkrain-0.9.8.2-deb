docker run -v `pwd`:/pongo checkra1n/build-pongo
